//Search
$(document).on('click','.nav-search',function(e) {
    e.preventDefault();
    $('.top-search-wrapper').addClass('search-in');
    $('body').css('overflow','hidden');
});

$(document).on('click','.btn-search-close',function(e){
    e.preventDefault();
    $('.top-search-wrapper').removeClass('search-in');
    $('body').css('overflow','auto');
});

//MMenu
$(document).ready(function () {
	if ( $(window).width() < 991) { 
		// MMenu
		$('#mobile-navmenu').mmenu({
			navbars	: [
				{
					position	: 'top',
					content		: [ 'searchfield' ]
				}, {
					position	: 'top',
					content		: [
						'prev',
						'title',
						'close'
					]
				}
			]
		}, {
         // configuration
         offCanvas: {
            pageSelector: ".wrapper"
         }
      });
    }
    
    // Filter Fixed
    var prevScrollTop = 0, currScrollTop, $header = $('.header'), headerHeight = $('.header').height();

    $(window).on('scroll',function(e){

        currScrollTop = $(this).scrollTop();

        if(currScrollTop < headerHeight){
            //$('body').css('padding-top',0);
            $header.removeClass('header--sticky animated slideInDown reveal');
        }else if(currScrollTop > prevScrollTop){
            $header.addClass('header--sticky').removeClass('animated slideInDown reveal');
            //$('body').css('padding-top',$filter.height()+'px');
        }else{
            $header.addClass('reveal animated slideInDown');
        }
        prevScrollTop = currScrollTop;
    });

}); 

// Sticky Header while scrolling
/* $(window).scroll(function() {
    $hHeight = $('.header').height();
    
    if($(this).scrollTop() > 99) {
        $('.header').addClass('header--sticky animated fadeInDown');
    } else {
        $('.header').removeClass('header--sticky animated fadeInDown');
    }
}); */

 



// Scroll to top
$(document).on('click','.back-to-top', function(e) {
    e.preventDefault();
    $('body,html').animate({
            scrollTop: 0
    }, 1000);
});
		

// FullScreen Bootstrap slider
$(document).ready(function () {
    if($('#fs-slider').length){
        var $item = $('#fs-slider .carousel-item'), $hHeight = $('.header').height(), $body = $('body');
        var $wHeight = $(window).height();

        $item.height($wHeight); 
        $item.addClass('fs-image');

        $('#fs-slider img').each(function() {
          var $src = $(this).attr('src');
          $(this).parent().css({'background-image' : 'url(' + $src + ')'});
          $(this).remove();
        });

        $(window).on('resize', function (){
          $hHeight = $('.header').height()
          $wHeight = $(window).height();
          $item.height($wHeight);
        });

        $('#fs-slider').carousel({
          interval: 7000,
          pause: "false"
        });

        $('.carousel-inner').each(function() {
            if($(this).children('div').length === 1){
                $(this).siblings('.carousel-control, .carousel-indicators').hide();   
            }
        });
    }else if($('.fullscreen-image').length){
        $imgDiv = $('.fullscreen-image');
        var $wHeight = $(window).height();
        $imgDiv.height($wHeight);

        $(window).on('resize', function (){
            $wHeight = $(window).height();
            $imgDiv.height($wHeight);
        });
    }
});

// Increment & Decrement
$('.btn-qty-plus').on('click',function(e){
    e.preventDefault();
    $.fn.updateValue(this, +1) ;
});

$('.btn-qty-minus').on('click',function(e){
    e.preventDefault();
    $.fn.updateValue(this, -1) ;
});

$.fn.updateValue = function(btn, operator){
    var inputBefore, inputAfter;
    inputBefore = $(btn).parent().siblings('#qty');
    inputAfter = parseInt(inputBefore.val(), 10) + operator;
    inputBefore.val(Math.max(inputAfter, 1));
};


//File Input Change
$('.button-file-input').on('change',function(e){
    var files = $(this)[0].files;
    
    //console.info(files)
    
    if(files.length > 1){
        $(this).siblings('.selected-file').html(files.length+' Files Selected');
    }else{
        $(this).siblings('.selected-file').html(files.length+' File Selected')
    }
});

//Video Play
$(document).on('click','.btn-play', function(e){
    e.preventDefault();
    
    $('#class-video').get(0).play();
    $(this).addClass('d-none');
    $(this).next().removeClass('d-none');

}).on('click','.btn-pause', function(e){
    e.preventDefault();
    $('#class-video').get(0).pause();

    $(this).addClass('d-none');
    $(this).prev().removeClass('d-none');
});