            <footer class="footer">
                <div class="footer__top">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-5 col-lg-4">
                                <div class="footer-column mb-30 mb-lg-0">
                                    <h6 class="mb-10 mb-md-20">Address</h6>
                                    <address class="mb-md-20">Powder Mill Plaza, Route 10 East 4 <br>Gibraltar Drive, Morris Plains, NJ 07950</address>
                                    <p><i class="icofont-phone"></i> 973.538.3811 <br> <i class="icofont-envelope"></i> info@depasqualethespa.com</p>
                                    <ul class="social-list">
                                        <li><a href="#"><i class="icofont-twitter"></i></a></li>
                                        <li><a href="#"><i class="icofont-facebook"></i></a></li>
                                        <li><a href="#"><i class="icofont-instagram"></i></a></li>
                                        <li><a href="#"><i class="icofont-youtube-play"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            
                            <div class="col-md-7 col-lg-8">
                                <div class="row">
                                    <div class="col-md-6 col-lg-3">
                                        <div class="footer-column mb-10 mb-md-30 mb-lg-0">
                                            <h6 class="mb-10 mb-md-20">Quick Links</h6>
                                            <ul class="footer-list">
                                                <li><a href="#">Hours of Operation</a></li>
                                                <li><a href="#">Direction</a></li>
                                                <li><a href="#">FAQ</a></li>
                                                <li><a href="#">Tour</a></li>
                                                <li><a href="#">Luxe Rewards</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-lg-3">
                                        <div class="footer-column mb-30 mb-lg-0">
                                            <h6 class="d-none d-md-block mb-10 mb-md-20">&nbsp;</h6>
                                            <ul class="footer-list">
                                                <li><a href="#">Client Testimonials</a></li>
                                                <li><a href="#">Career Opportunities</a></li>
                                                <li><a href="#">Standards</a></li>
                                                <li><a href="#">Press</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-lg-3">
                                        <div class="footer-column mb-30 mb-lg-0">
                                            <h6 class="mb-10 mb-md-20">Services</h6>
                                            <ul class="footer-list">
                                                <li><a href="#">The Spa</a></li>
                                                <li><a href="#">The Salon</a></li>
                                                <li><a href="#">Nail Services</a></li>
                                                <li><a href="#">Bridal Services</a></li>
                                                <li><a href="#">Other Services</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-lg-3">
                                        <div class="footer-column mb-30 mb-lg-0">
                                            <h6>Hours</h6>
                                            <ul class="footer-list">
                                                <li><strong>Mon - Thur</strong> 8am - 10pm</li>
                                                <li><strong>Fri</strong> 8am - 6pm</li>
                                                <li><strong>Sat</strong> 8am - 5pm</li>
                                                <li><strong>Sunday</strong> Closed</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div><!--/row -->
                            </div><!--/col-lg-9 -->
                        </div><!--/row -->
                    </div>
                </div>
                
                <div class="footer__bottom py-20 py-md-30">
                    <div class="container">
                        <p class="mb-0">Copyright &copy; 2020 Depasqualethespa. All rights reserved.</p>
                    <!--<span><a href="#">Privacy Policy</a> | <a href="#">Terms of Use</a> | <a href="#">Return Policy</a></span>-->
                    </div>
                </div>
			</footer>

        </div><!-- Wrapper -->
        
        <!-- Modals goes here... -->
        <!--/Modals goes here -->
 

        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/lucid.js"></script>
        <script>
            $(window).on('load', function() {
                $(this).impulse();
            });
        </script>

<?php if(isset($instagram_feed) && ($instagram_feed == 'yes')) { ?>
        <script src="assets/js/masonry.pkgd.min.js"></script>
        <script src="assets/js/imagesloaded.pkgd.min.js"></script>
		<script>
			$(document).ready(function(){
				var name = "depasqualethespa", items;

				$.get("https://images"+~~(Math.random()*33)+"-focus-opensocial.googleusercontent.com/gadgets/proxy?container=none&url=https://www.instagram.com/" + name + "/", function(html) {
					if (html) {
						var regex = /_sharedData = ({.*);<\/script>/m,
						  json = JSON.parse(regex.exec(html)[1]),
						  edges = json.entry_data.ProfilePage[0].graphql.user.edge_owner_to_timeline_media.edges;
												
						  var instaHtml = '<div class="i__grid-sizer"></div>';
						  $.each(edges, function(n, edge) {
                              var node = edge.node, gridClass;
							  if(n < 12 ){
							    gridClass = (n==4 || n==6)?'i__grid-item i__grid-item-large':'i__grid-item';
								instaHtml+="<div class='"+gridClass+"'><a class='instagram-item d-flex align-items-center justify-content-center' href='https://www.instagram.com/p/"+node.shortcode+"' target='_blank'><img class='img-fluid' src='"+node.thumbnail_resources[4].src+"'></a></div>";
							  }
						  });

						  $('#i__grid').html(instaHtml);
						  var $grid = $('#i__grid').imagesLoaded( function() {
                                $grid.masonry({
                                    itemSelector: '.i__grid-item',                
                                    columnWidth: '.i__grid-sizer',
                                    percentPosition: true
                                });
                            });
						}
					}).fail(function() {
						$('#i__grid').html('');
				    });
				});
		</script>
<?php } ?>

<?php if(isset($wow) && $wow == 'yes'){ ?>
		<script src="assets/js/wow.min.js"></script>
        <script>new WOW().init();</script>
<?php } ?>
		<script src="assets/js/bootstrap.bundle.min.js"></script> 
		<script src="assets/js/jquery.mmenu.all.js"></script>
		<script src="assets/js/main.js"></script>
<?php if(isset($slick) && $slick == 'yes'){ ?>
        <script src="assets/js/slick.min.js"></script>
        <script>
            $('.testimonial-carousel').slick({
                dots: true,
                arrows: false,
                infinite: true,
                autoplay: true,
                slidesToShow: 1,
                adaptiveHeight: true
            });
            $('.block-carousel').slick({
                dots: false,
                arrows: false,
                infinite: true,
                autoplay: true,
                slidesToShow: 1
            });
        </script>
<?php } ?>
	</body>
</html>