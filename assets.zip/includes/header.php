<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Depasquale The Spa</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Muli:300,400,500,600,700,800|Old+Standard+TT:400,400i,700&display=swap">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Bitter:400,400i,700&display=swap">
        <link rel="stylesheet" href="assets/style/icofont.min.css">
        <link rel="stylesheet" href="assets/style/jquery.mmenu.all.css">
		<link rel="stylesheet" href="assets/style/bootstrap.css">
        <link rel="stylesheet" href="assets/style/style.css">
   </head>
   <body>
	    
        <!-- Wrapper -->
        <div class="wrapper">
            
            <header class="header">
                <div class="container-fluid">
                    <nav class="navbar navbar-expand-lg custom-navbar-light navbar--desktop">
                        <a class="navbar-brand" href="index.php">
                            <img class="logo--white" src="assets/images/spa-white-2x.png" alt="Depasquale The Spa">
                            <img class="logo--black" src="assets/images/spa-2x.png" alt="Depasquale The Spa">
                        </a>    
                        <div class="ml-auto d-flex align-items-center">
                            <ul class="navbar-nav custom-navbar-nav">
                                <li class="nav-item hover-menu">
                                    <a href="#">Services <i class="icofont-rounded-down"></i></a>
                                    <div class="hover-menu__wrapper animated fadeInDown">
                                        <div class="row">
                                            <div class="col-md-3">
                                                <h4 class="hover-menu__title">The Spa</h4>
                                                <ul class="hover-menu__list">
                                                    <li><a href="#">Facials</a></li>
                                                    <li><a href="#">HydraFacial</a></li>
                                                    <li><a href="#">Massage Therapies</a></li>
                                                    <li><a href="#">Exfoliation & Body Bronzing</a></li>
                                                    <li><a href="#">Waxing</a></li>
                                                </ul>
                                            </div>
                                            <div class="col-md-3">
                                                <h4 class="hover-menu__title">The Salon</h4>
                                                <ul class="hover-menu__list">
                                                    <li><a href="#">Cutting & Styling</a></li>
                                                    <li><a href="#">Keratin & Texture Treatments</a></li>
                                                    <li><a href="#">Colour</a></li>
                                                    <li><a href="#">Hair & Scalp Therapies</a></li>
                                                    <li><a href="#">Wigs & Hair Extensions</a></li>
                                                </ul>
                                            </div>
                                            <div class="col-md-3">
                                                <h4 class="hover-menu__title">NAIL SERVICES</h4>
                                                <ul class="hover-menu__list">
                                                    <li><a href="#">Manicures</a></li>
                                                    <li><a href="#">Acrylics</a></li>
                                                    <li><a href="#">LCN Gel</a></li>
                                                    <li><a href="#">Pedicures</a></li>
                                                </ul>
                                            </div>
                                            <div class="col-md-3">
                                                <h4 class="hover-menu__title">Others</h4>
                                                <ul class="hover-menu__list">
                                                    <li><a href="#">EXPERIENCES & PACKAGES</a></li>
                                                    <li><a href="#">MEN'S SERVICES</a></li>
                                                    <li><a href="#">MAKE UP STUDIO</a></li>
                                                    <li><a href="#">BEAUTY BAR</a></li>
                                                    <li><a href="#">BRIDAL SERVICES</a></li>
                                                    <li><a href="#">DEPASQUALE KIDS</a></li>
                                                    <li><a href="#">PRICE LIST</a></li>
                                                </ul>
                                            </div>
                                        </div><!--/row-->
                                    </div>
                                </li>
                                <li class="nav-item"><a href="#">Events & Promotions</a></li>
                                <li class="nav-item"><a href="#">Bridal Services</a></li>
                                <li class="nav-item"><a href="#">Meet The Team</a></li> 
                                <li class="nav-item"><a href="#">Gift Cards</a></li> 
                            </ul>
                            <ul class="navbar-nav custom-navbar-nav ml-10 ml-xl-30">
                                <li class="nav-item mx-0"><a href="#" class="btn btn-light-2 hvr-sweep-to-right">Reserve Online!</a></li>
                            </ul>
                        </div>
                    </nav><!--/navbar--desktop-->

                    <nav class="navbar-expand-lg custom-navbar-light navbar--mobile">
                        <div class="home-top my-md-10 my-lg-20 d-flex align-items-center justify-content-between">
                            <div class="home-top__search">
                                <a class="site-search d-none d-lg-inline-block" href="#"><i class="icofont-search"></i></a>
                                <a class="navbar-toggler" href="#mobile-navmenu">
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </a>
                            </div>
                            <div class="home-top__logo">
                                <a class="navbar-brand" href="index.php">
                                    <img class="logo--white" src="assets/images/spa-white-2x.png" alt="Depasquale The Spa">
                                    <img class="logo--black" src="assets/images/spa-2x.png" alt="Depasquale The Spa">
                                </a>
                            </div>
                            <div class="home-top__button">
                                <a class="site-search d-inline-block d-lg-none" href="#"><i class="icofont-search"></i></a>
                                <a href="#" class="btn btn-light-2 hvr-sweep-to-right d-none d-lg-inline-block">Reserve Online!</a>
                            </div>
                        </div>
                        <div class="header--menu d-none d-lg-flex align-items-center justify-content-center">
                            <ul class="navbar-nav custom-navbar-nav">
                                <li class="nav-item hover-menu">
                                    <a href="#">Services <i class="icofont-rounded-down"></i></a>
                                    <div class="hover-menu__wrapper animated fadeInDown">
                                        <div class="row">
                                            <div class="col-md-3">
                                                <h4 class="hover-menu__title">The Spa</h4>
                                                <ul class="hover-menu__list">
                                                    <li><a href="#">Facials</a></li>
                                                    <li><a href="#">HydraFacial</a></li>
                                                    <li><a href="#">Massage Therapies</a></li>
                                                    <li><a href="#">Exfoliation & Body Bronzing</a></li>
                                                    <li><a href="#">Waxing</a></li>
                                                </ul>
                                            </div>
                                            <div class="col-md-3">
                                                <h4 class="hover-menu__title">The Salon</h4>
                                                <ul class="hover-menu__list">
                                                    <li><a href="#">Cutting & Styling</a></li>
                                                    <li><a href="#">Keratin & Texture Treatments</a></li>
                                                    <li><a href="#">Colour</a></li>
                                                    <li><a href="#">Hair & Scalp Therapies</a></li>
                                                    <li><a href="#">Wigs & Hair Extensions</a></li>
                                                </ul>
                                            </div>
                                            <div class="col-md-3">
                                                <h4 class="hover-menu__title">NAIL SERVICES</h4>
                                                <ul class="hover-menu__list">
                                                    <li><a href="#">Manicures</a></li>
                                                    <li><a href="#">Acrylics</a></li>
                                                    <li><a href="#">LCN Gel</a></li>
                                                    <li><a href="#">Pedicures</a></li>
                                                </ul>
                                            </div>
                                            <div class="col-md-3">
                                                <h4 class="hover-menu__title">Others</h4>
                                                <ul class="hover-menu__list">
                                                    <li><a href="#">EXPERIENCES & PACKAGES</a></li>
                                                    <li><a href="#">MEN'S SERVICES</a></li>
                                                    <li><a href="#">MAKE UP STUDIO</a></li>
                                                    <li><a href="#">BEAUTY BAR</a></li>
                                                    <li><a href="#">BRIDAL SERVICES</a></li>
                                                    <li><a href="#">DEPASQUALE KIDS</a></li>
                                                    <li><a href="#">PRICE LIST</a></li>
                                                </ul>
                                            </div>
                                        </div><!--/row-->
                                    </div>
                                </li>

                                <li class="nav-item"><a href="#">Events & Promotions</a></li>
                                <li class="nav-item"><a href="#">Bridal Services</a></li>
                                <li class="nav-item"><a href="#">Meet The Team</a></li> 
                                <li class="nav-item"><a href="#">Gift Cards</a></li>
                            </ul>
                        </div>  
                    </nav><!--/navbar--mobile-->
                </div>
            </header>

            <nav id="mobile-navmenu">
                <ul>
                    <li>
                        <span>Services</span>
                        <ul>
                            <li>
                                <span>The Spa</span>
                                <ul>
                                    <li><a href="#">Facials</a></li>
                                    <li><a href="#">HydraFacial</a></li>
                                    <li><a href="#">Massage Therapies</a></li>
                                    <li><a href="#">Exfoliation & Body Bronzing</a></li>
                                    <li><a href="#">Waxing</a></li>
                                </ul>
                            </li>
                            <li>
                                <span>The Salon</span>
                                <ul>
                                    <li><a href="#">Cutting & Styling</a></li>
                                    <li><a href="#">Keratin & Texture Treatments</a></li>
                                    <li><a href="#">Colour</a></li>
                                    <li><a href="#">Hair & Scalp Therapies</a></li>
                                    <li><a href="#">Wigs & Hair Extensions</a></li>
                                </ul>
                            </li>
                            <li>
                                <span>NAIL SERVICES</span>
                                <ul>
                                    <li><a href="#">Manicures</a></li>
                                    <li><a href="#">Acrylics</a></li>
                                    <li><a href="#">LCN Gel</a></li>
                                    <li><a href="#">Pedicures</a></li>
                                </ul>
                            </li>
                            <li>
                                <span>Others</span>
                                <ul>
                                    <li><a href="#">EXPERIENCES & PACKAGES</a></li>
                                    <li><a href="#">MEN'S SERVICES</a></li>
                                    <li><a href="#">MAKE UP STUDIO</a></li>
                                    <li><a href="#">BEAUTY BAR</a></li>
                                    <li><a href="#">BRIDAL SERVICES</a></li>
                                    <li><a href="#">DEPASQUALE KIDS</a></li>
                                    <li><a href="#">PRICE LIST</a></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li><a href="#">Events & Promotions</a></li>
                    <li><a href="#">Bridal Services</a></li>
                    <li><a href="#">Meet The Team</a></li> 
                    <li><a href="#">Gift Cards</a></li> 
                    <li><a href="#">Reserve Online!</a></li>
                </ul>
            </nav>
 