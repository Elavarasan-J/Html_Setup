		    
			<footer class="footer">
                <div class="footer__top">
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-5 col-lg-3">
                                <div class="footer-column">
                                    <h6>Address</h6>
                                    <address>Powder Mill Plaza, Route 10 East 4 <br>Gibraltar Drive, Morris Plains, <br>NJ 07950</address>
                                    <ul class="social-list">
                                        <li><a href="#"><i class="icofont-facebook"></i></a></li>
                                        <li><a href="#"><i class="icofont-twitter"></i></a></li>
                                        <li><a href="#"><i class="icofont-instagram"></i></a></li>
                                        <li><a href="#"><i class="icofont-youtube-play"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            
                            <div class="col-sm-7 col-lg-9">
                                <div class="row">
                                    <div class="col-sm-6 col-lg-3">
                                        <div class="footer-column">
                                            <h6>Quick Links</h6>
                                            <ul class="footer-list">
                                                <li><a href="#">Hours of Operation</a></li>
                                                <li><a href="#">Direction</a></li>
                                                <li><a href="#">FAQ</a></li>
                                                <li><a href="#">Tour</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col-sm-6 col-lg-3">
                                        <div class="footer-column">
                                            <h6>&nbsp;</h6>
                                            <ul class="footer-list">
                                                <li><a href="#">Client Testimonials</a></li>
                                                <li><a href="#">Career Opportunities</a></li>
                                                <li><a href="#">Standards</a></li>
                                                <li><a href="#">Press</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col-sm-6 col-lg-3">
                                        <div class="footer-column">
                                            <h6>My Account</h6>
                                            <ul class="footer-list">
                                                <li><a href="#">Profile</a></li>
                                                <li><a href="#">Returns & Exchanges</a></li>
                                                <li><a href="#">Manage Addresses</a></li>
                                                <li><a href="#">My Orders</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col-sm-6 col-lg-3">
                                        <div class="footer-column">
                                            <h6>Hours</h6>
                                            <ul class="footer-list">
                                                <li><strong>Mon - Thur</strong> 8am - 10pm</li>
                                                <li><strong>Fri</strong> 8am - 6pm</li>
                                                <li><strong>Sat</strong> 8am - 5pm</li>
                                                <li><strong>Sunday</strong> Closed</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div><!--/row -->
                            </div><!--/col-lg-9 -->
                        </div><!--/row -->
                    </div>
                </div>
                
                <div class="footer__bottom">
                    <div class="container">
                        <p>Copyright &copy; 2019 Depasqualethespa. All Rights reserved.</p>
                        <span><a href="#">Privacy Policy</a> | <a href="#">Terms of Use</a> | <a href="#">Return Policy</a></span>
                    </div>
                </div>
			</footer> 

            <!--Team Modal-->
            <div class="modal fade team-modal" id="teamModal" tabindex="-1" role="dialog" aria-labelledby="teamModalLabel">
              <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content ">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg></button>
                        <div class="modal-body p-0"></div>
                    </div>
                </div>
            </div><!--/Team Modal-->

		</div><!--/Wrapper -->
        
		<script src="js/jquery.min.js"></script>
        <script src="js/bootstrap-bundle.min.js"></script>

<?php if(isset($instagram_feed) && ($instagram_feed == 'yes')) { ?>
        <script src="js/masonry.pkgd.min.js"></script>
        <script src="js/imagesloaded.pkgd.min.js"></script>
		<script>
			$(document).ready(function(){
				var name = "depasqualethespa", items;

				$.get("https://images"+~~(Math.random()*33)+"-focus-opensocial.googleusercontent.com/gadgets/proxy?container=none&url=https://www.instagram.com/" + name + "/", function(html) {
					if (html) {
						var regex = /_sharedData = ({.*);<\/script>/m,
						  json = JSON.parse(regex.exec(html)[1]),
						  edges = json.entry_data.ProfilePage[0].graphql.user.edge_owner_to_timeline_media.edges;
												
						  var instaHtml = '<div class="i__grid-sizer"></div>';
						  $.each(edges, function(n, edge) {
							  var node = edge.node, gridClass;
							  if(n < 12 ){
							    gridClass = (n==4 || n==6)?'i__grid-item i__grid-item-large':'i__grid-item';
								instaHtml+="<div class='"+gridClass+"'><a class='instagram-item d-flex align-items-center justify-content-center' href='https://www.instagram.com/p/"+node.shortcode+"' target='_blank'><img class='img-fluid' src='"+node.thumbnail_resources[4].src+"'></a></div>";
							  }
						  });

						  $('#i__grid').html(instaHtml);
						  var $grid = $('#i__grid').imagesLoaded( function() {
                                $grid.masonry({
                                    itemSelector: '.i__grid-item',                
                                    columnWidth: '.i__grid-sizer',
                                    percentPosition: true
                                });
                            });
						}
					}).fail(function() {
						$('#i__grid').html('');
				    });
				});
		</script>
<?php } ?>
  
    <?php if(isset($slick) && $slick=='yes') { ?>
        <script src="js/slick.min.js"></script> 
        <script>
			$('.featured-slick__carousel').slick({
              infinite: false,
              speed: 300,
              slidesToShow: 3,
              slidesToScroll: 1,
              nextArrow:'<img class="next" src="images/next-button.png" alt="Next">',
              prevArrow:'<img class="prev" src="images/prev-button.png" alt="Previous">',
              responsive: [
                {
                  breakpoint: 1024,
                  settings: {
                    slidesToShow: 2,
                  }
                },
                {
                  breakpoint: 480,
                  settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                  }
                }]
			});
            
            //Best Seller
            $('.bestseller-slick__carousel').slick({
              infinite: false,
              speed: 300,
              slidesToShow: 4,
              slidesToScroll: 4,
              nextArrow:'<img class="next" src="images/next-button.png" alt="Next">',
              prevArrow:'<img class="prev" src="images/prev-button.png" alt="Previous">',
              responsive: [
                {
                  breakpoint: 1259,
                  settings: {
                    slidesToShow: 3,
                    slidesToScroll: 3
                  }
                },
                {
                  breakpoint: 1024,
                  settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2
                  }
                }]
			});
        </script>
    <?php } ?>
        <script src="js/main.js"></script>
    </body>
</html>